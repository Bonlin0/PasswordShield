package cn.adminzero.passwordshield_demo0.FaceManger.ResultClass;

public class GroupGetListResult {
    private String group_id_list;

    public String getGroup_id_list() {
        return group_id_list;
    }

    public void setGroup_id_list(String group_id_list) {
        this.group_id_list = group_id_list;
    }
}
