package cn.adminzero.passwordshield_demo0.FaceManger.ResultClass;

import java.lang.reflect.Array;

public class getUsersResult {
    private Array user_id_list;

    public Array getUser_id_list() {
        return user_id_list;
    }

    public void setUser_id_list(Array user_id_list) {
        this.user_id_list = user_id_list;
    }
}
