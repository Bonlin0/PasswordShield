package cn.adminzero.passwordshield_demo0.entity;

/**
 * app控制列表
 * 哪些app可以
 * 被软件控制
 */
public class ControledApp {
    private int id;
    private String packageName;
}
